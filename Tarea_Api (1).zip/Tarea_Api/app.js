const options = {
	method: 'GET',
	headers: {
		'X-RapidAPI-Key': '748af0bc2fmsh3d2282ee0f0639ap190c41jsnf6928169320f',
		'X-RapidAPI-Host': 'imdb8.p.rapidapi.com'
	}
};


fetch('https://imdb8.p.rapidapi.com/auto-complete?q=Avengers%20', options)
	.then(response => response.json())
	.then(response => {
		
		console.log(response.d)
	const {d=[]} = response;
        
	//console.log(Search);
	document.getElementById("lista").innerHTML='';

	d.map((p)=>{
		document.getElementById("lista").innerHTML+=`<div style="margin-top:10px;">
				 ${p.l}
	</div>`;
	})
});



	// //.then(data =>{
	// 	//const list = data.d;

	// 	const {d=[]}=response;
	// 	d.map((item) => {
	// 		//console.log(item)
    //         //const name = item.l;
	// 		//const poster = item.i.imageUrl;
	// 		//const movie = `<li><img src="${poster}"><h2>${name}</h2></li>` 
	// 		//document.querySelector('.movies').innerHTML =+ movie;

	// 	})
	
	//}).catch(err => console.error(err));